import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { CompanyApiService } from '../../core/company-api.service';
import { SidebarComponent } from '../../core/layout/sidebar.component';
import { DepartmentStatusGroup, groupPeopleByDepartmentWithStatus } from '../../core/work-status';

@Component({standalone:true,imports:[CommonModule,RouterLink,SidebarComponent],templateUrl:'./people.component.html',styleUrl:'./people.component.scss'})
export class PeopleComponent implements OnInit {
  groups = signal<DepartmentStatusGroup[]>([]);

  constructor(public auth: AuthService, private api: CompanyApiService) {}

  ngOnInit() {
    const isAdmin = this.auth.user()?.role === 'ADMIN';
    const peopleRequest = isAdmin ? this.api.users() : this.api.departmentMembers();
    const attendanceRequest = isAdmin ? this.api.allAttendance() : this.api.departmentAttendance();

    peopleRequest.subscribe(people => {
      attendanceRequest.subscribe(records => {
        this.groups.set(groupPeopleByDepartmentWithStatus(people, records));
      });
    });
  }
}
